-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2023-06-04 13:01:32
-- 服务器版本： 10.4.24-MariaDB
-- PHP 版本： 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `carrental`
--

-- --------------------------------------------------------

--
-- 表的结构 `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `BookingNumber` bigint(12) DEFAULT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `LastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `BookingNumber`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`, `LastUpdationDate`) VALUES
(3, NULL, '12345@gmail.com', 10, '2023-05-16', '2023-05-17', 'i want this car ,give me the key ', 0, '2023-05-29 16:26:03', NULL),
(4, NULL, '12345@gmail.com', 11, '2023-05-10', '2023-05-28', 'jajaja', 0, '2023-05-30 08:28:57', NULL),
(5, NULL, 'james0277@gmail.com', 16, '2023-06-01', '2023-06-07', 'jj', 1, '2023-05-31 16:45:35', '2023-06-01 05:55:28'),
(6, NULL, 'james0277@gmail.com', 10, '2023-06-03', '2023-06-09', 'test book', 0, '2023-06-02 05:59:32', NULL),
(7, NULL, 'james0277@gmail.com', 11, '2023-06-03', '2023-06-08', 'test rolls', 1, '2023-06-02 06:02:35', '2023-06-02 06:03:12');

-- --------------------------------------------------------

--
-- 表的结构 `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(2, 'BMW', '2023-06-03 16:24:50', NULL),
(3, 'Audi', '2023-06-03 16:25:03', NULL),
(8, 'Rolls-Royce', '2023-05-29 12:40:06', NULL),
(9, 'Lamborghini', '2023-05-29 12:40:25', NULL),
(10, 'Ferrari', '2023-05-29 13:14:34', NULL),
(11, 'Mercedes-Benz', '2023-06-01 08:33:06', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'LOT 6, BUKIT NAU,JALAN LAPANGAN TERBANG,PADANG MATSIRAT,07000 LANGKAWI, KEDAH.', 'JJVcarrental@gmail.com', '014-0806027');

-- --------------------------------------------------------

--
-- 表的结构 `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'Terms and Conditions', 'terms', '																				<p align=\"justify\"><font size=\"2\"><strong><font color=\"#990000\">(1) ACCEPTANCE OF TERMS</font><br><br></strong>Welcome to JJV Car Rental Langkawi. JJV Car Rental&nbsp; langkawi Private Limited (\"JJV Car Rental,\" \"we,\" or \"us\") provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: http://in.docs.jjvcarrental.com/info/terms/. In addition, when using particular JJV Car Rental services or third-party services, you and JJV Car Rental shall be subject to any posted guidelines or rules applicable to such services, which may be posted from time to time. All such guidelines or rules, which may be subject to change, are hereby incorporated by reference into the TOS. In most cases, the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Service, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Service. JJV Car Rental also may offer other services from time to time that are governed by different Terms of Service. These TOS do not apply to such other services that are governed by different Terms of Service.<br></font></p>\r\n										\r\n										'),
(2, 'Privacy Policy', 'privacy', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</span>'),
(3, 'About Us ', 'aboutus', '<span style=\"color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 13.3333px;\">We offer a varied fleet of cars, ranging from the compact. All our vehicles have air conditioning, &nbsp;power steering, electric windows. All our vehicles are bought and maintained at official dealerships only. Automatic transmission cars are available in every booking class.&nbsp;</span><span style=\"color: rgb(52, 52, 52); font-family: Arial, Helvetica, sans-serif;\">As we are not affiliated with any specific automaker, we are able to provide a variety of vehicle makes and models for customers to rent.</span><div><span style=\"color: rgb(62, 62, 62); font-family: &quot;Lucida Sans Unicode&quot;, &quot;Lucida Grande&quot;, sans-serif; font-size: 11px;\">ur mission is to be recognised as the global leader in Car Rental for companies and the public and private sector by partnering with our clients to provide the best and most efficient Cab Rental solutions and to achieve service excellence.</span><span style=\"color: rgb(52, 52, 52); font-family: Arial, Helvetica, sans-serif;\"><br></span></div>'),
(11, 'FAQs', 'faqs', '																														<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Address------Test &nbsp; &nbsp;dsfdsfds</span>');

-- --------------------------------------------------------

--
-- 表的结构 `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `tbltestimonial`
--

CREATE TABLE `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tbltestimonial`
--

INSERT INTO `tbltestimonial` (`id`, `UserEmail`, `Testimonial`, `PostingDate`, `status`) VALUES
(2, '12345@gmail.com', 'i live like this car', '2023-05-30 14:08:00', NULL),
(3, 'james0277@gmail.com', 'nice good car service', '2023-05-30 16:32:26', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(2, 'Joel Chian', 'bdiabi@gmail.com', '6f3062b886eaad372ddfd2e7e002b296', '0123456789', NULL, NULL, NULL, NULL, '2023-05-24 12:45:38', NULL),
(3, 'james', '11111@gmail.com', 'b59c67bf196a4758191e42f76670ceba', '11111', NULL, NULL, NULL, NULL, '2023-05-29 16:14:50', NULL),
(4, 'james', 'james027@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '11111', NULL, NULL, NULL, NULL, '2023-05-29 16:17:12', NULL),
(5, 'jameslow', '1234@gmail.com', 'b4cc344d25a2efe540adbf2678e2304c', '11111', NULL, NULL, NULL, NULL, '2023-05-29 16:19:21', NULL),
(6, 'kaka', '12345@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '0100101010', NULL, NULL, NULL, NULL, '2023-05-29 16:22:25', NULL),
(7, 'jjv customer', 'jjv@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01234567', NULL, NULL, NULL, NULL, '2023-05-30 06:15:43', NULL),
(8, 'jameslow', '12345678@gmail.com', '25f9e794323b453885f5181f1b624d0b', '12345678', NULL, NULL, NULL, NULL, '2023-05-30 14:22:42', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `id` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(10, 'BMW I7', 2, 'The BMW i7 is equipped with a high-capacity battery pack, with an estimated capacity of 100 kWh. The BMW i7 has an estimated range of approximately 400 miles (about 644 kilometers). The BMW i7 is equipped with a powerful electric drivetrain, providing a total power output of around 500 horsepower. It can accelerate from 0 to 60 mph (0 to 96 km/h) in approximately 4 seconds. The BMW i7 provides a luxurious and comfortable driving experience. It offers premium seats, a luxurious interior, advanced driver-assistance systems, a high-end audio system, and a large touchscreen display, among other features.\r\n', 750, 'Petrol', 2022, 5, 'bmwi74.jpg', 'bmwi75.jpg', 'bmwi7.jpg', 'bmwi72.jpg', 'bmwi73.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-05-29 11:58:46', '2023-05-30 08:42:18'),
(11, 'Rolls-Royce Phantom', 8, 'The Rolls-Royce Phantom is the ultimate symbol of automotive extravagance and status. Its iconic design and commanding presence convey wealth and exclusivity. The 2023 Phantom sets itself apart from rivals with a significantly higher price, offering unparalleled luxury and comfort. It effortlessly glides over imperfections, indulging passengers with sumptuous materials. Its V12 engine provides effortless power while remaining almost silent. Customization options are virtually endless, ensuring each Phantom is unique. While a chauffeur is not included, it can be arranged separately. The Rolls-Royce Phantom represents the pinnacle of luxury, catering to the desires of the elite few.', 1100, 'Petrol', 2022, 4, 'rolls1.png', 'rolls2.png', 'rollys3.png', 'rollysindes2.png', 'rollys5.png', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-05-29 13:09:02', NULL),
(13, 'BMW X3', 2, 'BMW X3\r\nTraditionally, sports sedans have been the vehicles that best projected the spirit of the BMW brand. Not so much anymore. The 2023 X3 SUV edges in on its four-door brethren\'s territory with a satisfying blend of refinement and driver engagement. M40i models get a boost from the company\'s revered 382-hp turbo six—an engine that never ceases to amaze us with its velvety muscle. A handsome exterior design gives the X3 enough curb appeal to fit in among style mavens such as the Genesis GV70 and Volvo XC60. The X3\'s spacious interior is soberly styled but lined with premium materials and desirable technology. But it\'s the X3\'s frisky handling that endears it most to enthusiast drivers like those on our staff and, as an added bonus, its athletic road manners don\'t compromise its genteel nature when cruising nor its all-around SUV practicality.', 800, 'Petrol', 2022, 5, 'bmwx31.jpg', 'bmwx32.jpg', 'bmwx33.jpg', 'bmwx37.jpg', 'bmwx36.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2023-05-29 13:12:26', NULL),
(14, 'Huracán STO', 9, 'A super-sports car created with a singular purpose, the Huracán STO delivers all the feel and technology of a genuine race car in a road-legal model. Lamborghini’s years-long motorsport know-how, intensified by a winning heritage, is concentrated in the new Huracán STO. Its extreme aerodynamics, track-honed handling dynamics, lightweight contents and the highest-performing V10 engine to date come together, ready to trigger all the emotions of the racetrack in your everyday life.', 700, 'Petrol', 2022, 2, 'lamboghini4.jpg', 'lamboghini2.jpg', 'lamboghini56.jpg', 'lamnoghini.jpg', 'Lamborghini-Huracan-STO-interior.jpg', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, 1, '2023-05-29 13:14:18', NULL),
(15, 'RS6 Avant', 3, '\r\nThe Audi RS 6 Avant is an extraordinary high-performance wagon offered by Audi. Combining the practicality of a spacious estate car with the power and agility of a sports car?Under the hood, the RS 6 Avant packs a potent punch. It is equipped with a twin-turbocharged 4.0-liter V8 engine that delivers exhilarating performance. With its impressive power output and quick acceleration, the RS 6 Avant can go from 0 to 60 mph in just a few seconds, showcasing its sports car DNA.', 700, 'Petrol', 2022, 5, 'audirs6.jpg', 'Audi-RS6-Interior.jpg', 'audirs62.jpg', 'audirs63.jpg', 'audirs66.jpg', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, 1, '2023-05-29 13:28:08', NULL),
(16, 'Audi Q8', 3, 'The Audi Q8 combines the elegance of a four-door luxury coupé with the versatility of an SUV. Expressive design with new Singleframe and features from the original Audi quattro. The sporty interior conveys luxurious charm; and together with the sliding rear seat bench plus, it offers even more space in the rear. The sporty but luxurious elegant nature of the interior, touch operating concept and high-tech navigation makes it the ideal accompaniment for business or leisure. ', 850, 'Petrol', 2023, 5, 'audiq82.jpg', 'audiq8.jpg', 'audiq84.jpg', 'audi q87.jpg', 'audi q89.jpg.png', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, 1, '2023-05-29 13:34:51', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `update_admin`
--

CREATE TABLE `update_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `update_admin`
--

INSERT INTO `update_admin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'Joel', '199c8e3e6f632a3f5a7f15116e745070'),
(2, 'James', '14c21688c5cdb71fc7db408185cff370');

--
-- 转储表的索引
--

--
-- 表的索引 `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`);

--
-- 表的索引 `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `update_admin`
--
ALTER TABLE `update_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- 使用表AUTO_INCREMENT `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 使用表AUTO_INCREMENT `update_admin`
--
ALTER TABLE `update_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
