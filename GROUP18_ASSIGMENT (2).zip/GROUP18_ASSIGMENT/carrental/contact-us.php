<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['send']))
  {
$name=$_POST['fullname'];
$email=$_POST['email'];
$contactno=$_POST['contactno'];
$message=$_POST['message'];
$sql="INSERT INTO  tblcontactusquery(name,EmailId,ContactNumber,Message) VALUES(:name,:email,:contactno,:message)";
$query = $dbh->prepare($sql);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':contactno',$contactno,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Query Sent. We will contact you shortly";
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>

<title>JJV Car Rental | Contact Us</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=ZCOOL+QingKe+HuangYou&display=swap" rel="stylesheet">

<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">    
<!-- shortcut icons -->
<link rel="shortcut icon" href="assets/images/logos.png">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

body{
  background: #000000;
  background-size: cover;
}

.col-md-6 .contact-detail{
  color: white;
}

#map{
  border-radius: 8%;
  width: 500px;
  height:380px;

}

h3{
  font-family: 'ZCOOL QingKe HuangYou', sans-serif;
}

.contact_form{
  background: #303030;
  box-shadow: 0 3px 6px  #303030, 0 3px 6px 0 #fff;
}

.control-label ,h3{
  color: white;
}

#contact_input{
  border-radius: 0;
  border-left: 0;
  border-top: 0;
  border-right: 0;
  border-bottom: 1px solid #999;
  background: transparent;
}

#send{
  padding: 0;
}

#info{
  color: white;
}

.page-header{
  background :url(assets/images/Contactus.jpg);
  background-size: cover;
  background-position: center;
}

#back-top i{
  padding: 0;
}
#icon_wrap {
  padding-right: 20px;
}

#icon_wrap2 {
  padding-right: 30px;
}

h1{
  font-family: 'ZCOOL QingKe HuangYou', sans-serif;
}

#maphyper{
  color: white;
}
</style>
</head>
<body>
<!--Header-->
<?php include('includes/header.php');?>

<!--Page Header-->
<section class="page-header contactus_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>Contact Us</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li>Contact Us</li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>

<!--Contact-us-->
<section class="contact_us section-padding">
  <div class="container">
    <div  class="row">
      <div  class="col-md-6">
        <h3>Get in touch using the form below</h3>
          <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <div class="contact_form gray-bg">
          <form  method="post">
            <div class="form-group">
              <label class="control-label">Full Name <span>*</span></label>
              <input id="contact_input"type="text" name="fullname" class="form-control white_bg" id="fullname" placeholder="Enter full name..." required>
            </div>
            <div class="form-group">
              <label class="control-label">Email Address <span>*</span></label>
              <input id="contact_input" type="email" name="email" class="form-control white_bg" id="emailaddress" placeholder="Enter your email..." required>
            </div>
            <div class="form-group">
              <label class="control-label">Phone Number <span>*</span></label>
              <input id="contact_input" type="text" name="contactno" class="form-control white_bg" id="phonenumber" placeholder="Enter your phone number..." required maxlength="10" pattern="[0-9]+">
            </div>
            <div class="form-group">
              <label class="control-label">Message <span>*</span></label>
              <textarea id="contact_input" class="form-control white_bg" name="message" rows="4" placeholder="Write down your question..."required></textarea>
            </div>
            <div class="form-group">
              <button class="btn" type="submit" name="send" type="submit">Send Message <span class="angle_arrow"><i id="send" class="fa fa-angle-right" aria-hidden="true"></i></span></button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-6">
        <h3>Contact Info</h3>
        <div class="contact_detail">
        <p><iframe id="map"src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.4000762445166!2d99.72981932376213!3d6.342201408710044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304c79a41205340b%3A0xc085ff131aed0105!2sLangkawi%20Car%20Rental%20by%20LangkawiGo!5e0!3m2!1sen!2smy!4v1685689679331!5m2!1sen!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
              <?php 
$pagetype=$_GET['type'];
$sql = "SELECT Address,EmailId,ContactNo from tblcontactusinfo";
$query = $dbh -> prepare($sql);
$query->bindParam(':pagetype',$pagetype,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
          <ul>
            <li>
              <div class="icon_wrap"><i id="icon_wrap" class="fa fa-map-marker" aria-hidden="true"></i></div>
              <div id="info" class="contact_info_m"><a id="maphyper" href="https://goo.gl/maps/QPjgHf3Heak56iqv5"><?php   echo htmlentities($result->Address); ?></a></div>
            </li>
            <li>
              <div  class="icon_wrap"><i id="icon_wrap2"class="fa fa-envelope-o" aria-hidden="true"></i></div>
              <div class="contact_info_m"><a id="info" href="tel:61-1234-567-90"><?php   echo htmlentities($result->EmailId); ?></a></div>
            </li>
            <li>
              <div  class="icon_wrap"><i id="icon_wrap" class="fa fa-phone" aria-hidden="true"></i></div>
              <div class="contact_info_m"><a id="info" href="mailto:contact@exampleurl.com"><?php   echo htmlentities($result->ContactNo); ?></a></div>
            </li>
          </ul>
        <?php }} ?>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /Contact-us--> 

<!--Footer -->
<?php include('includes/footer.php');?>

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>

<!--Login-Form -->
<?php include('includes/login.php');?>

<!--Register-Form -->
<?php include('includes/registration.php');?>

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>
</html>
